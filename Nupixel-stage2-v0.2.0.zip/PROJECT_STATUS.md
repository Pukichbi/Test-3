# Project status

**Stage:** 2 — Canvas Engine. Code written, **not built, not run**. Stage 1 (0.1.0) built via GitHub Actions and accepted by the user.
**Version:** 0.2.0 (versionCode 2)

## Stage 2 done (written, unverified)
- Rotation in the view transform; gestures: pan, pinch zoom, two-finger rotate, double tap fit/100%; rotation reset chip; "Center view".
- Document coordinates ↔ screen coordinates with rotation, unit-tested (`ViewTransformTest`).
- Rendering split: `DocumentLayer` (checkerboard + tiles) and `OverlayLayer` (outline, grid, guides).
- Tiled rendering: 512 px tiles, LRU cache, background half-resolution pyramid levels (`render/TilePyramid.kt`, `core/TileGrid.kt`).
- Canvas sheet: crop (numeric), canvas size with 3×3 anchor and background, resolution (resample, keep proportions); one-step undo.
- Grid (auto step by zoom) and guides (add by position, center guides, delete, saved in the project as optional `guides`).
- Memory limits: `Limits.fits()` used for canvas size and resolution; OOM reported as a message, document kept.

## Not done / limits
- Never compiled: expect compile errors on first build; fix them first.
- No device run, no screenshots, tile seams / gesture feel / grid look not visually verified.
- Crop has no on-canvas handles (numeric only); guides cannot be dragged; no snapping (arrives with tools in stage 3).
- Only one undo step for canvas operations; full history is stage 5.
- Session is still lost if Android kills the process (stage 5).

## Next action
Build (GitHub Actions), run `testDebugUnitTest`, then verify stage 2 criteria on a device: smooth gestures without jumps, large image (e.g. 8000 px) pan/zoom, crop / canvas size / resolution, guides saved and reloaded, memory limit messages.
