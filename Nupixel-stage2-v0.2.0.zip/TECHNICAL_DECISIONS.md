# Technical decisions

| # | Decision | Reason / consequence |
|---|----------|----------------------|
| 1 | Kotlin + Jetpack Compose, single Gradle module, packages per future engine | Fast to build; split into modules when engines appear (stage 2+). |
| 2 | `AppCompatActivity` as host | Needed for per-app language switching with persistence (`AppCompatDelegate.setApplicationLocales` + `autoStoreLocales`). |
| 3 | Project = zip `.npx` (`manifest.json` + `layers/*.png`) | Documented, inspectable, extensible to many layers; PNG is lossless. See `docs/PROJECT_FORMAT.md`. |
| 4 | Safe save: tmp file → verify → rename with `.bak`, recovered on start | A failed save never destroys the previous version. |
| 5 | `org.json` for the manifest | Built into Android, no plugin; JVM tests use the `org.json` artifact. |
| 6 | Max 8192 px side and ≤24 MP, further capped by heap (`core/Limits.kt`) | One full bitmap is drawn by Compose; above ~100 MB the canvas refuses to draw. Replaced by tiles in stage 2. |
| 7 | Photo Picker / system file dialogs, no storage permissions | Fewer permissions; works offline. |
| 8 | Theme and language stored separately (prefs / AppCompat) | Theme default is dark as required. |
| 9 | Only working UI is shown | No placeholders for layers/tools until they exist. |
| 10 | minSdk 24, targetSdk/compileSdk 35 | Wide device coverage, current platform. |
| 11 | Rendering split: `DocumentLayer` (checkerboard + tiles) and `OverlayLayer` (outline, grid, guides); gestures live in the editor | Editor aids never touch document pixels; later tools add their own overlays. |
| 12 | Tiles of 512 px cut lazily from the bitmap, LRU of 96 per level; half-resolution pyramid levels built in the background | Keeps draw calls and textures small on large documents. Costs up to ~33% extra memory for levels. Tiles are drawn without anti-aliasing to avoid seams. |
| 13 | View transform has rotation; 100% = 1 document px per screen px | Rotation by two-finger twist; reset chip appears when rotated. |
| 14 | Canvas operations (crop / canvas size / resolution) replace the whole bitmap and keep ONE undo step | Real history is stage 5; the single step avoids irreversible edits meanwhile. |
| 15 | Guides stored in `manifest.json` as optional `guides` | Backward compatible, no format version bump. |
| 16 | Crop is numeric (X, Y, W, H), no on-canvas handle yet | Handle-based crop arrives with the stage 3 selection tools. |
