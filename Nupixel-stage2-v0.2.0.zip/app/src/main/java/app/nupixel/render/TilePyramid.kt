package app.nupixel.render

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import app.nupixel.core.TileGrid
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** LRU cache of 512 px tiles cut from one bitmap. Used only from the draw thread. */
class TileCache(private val source: Bitmap, private val maxTiles: Int = 96) {
    private val tiles = object : LinkedHashMap<Long, ImageBitmap>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, ImageBitmap>?): Boolean = size > maxTiles
    }

    fun tile(tx: Int, ty: Int): ImageBitmap {
        val key = ty.toLong() * 100_000L + tx
        return tiles.getOrPut(key) {
            val t = TileGrid.TILE
            val x = tx * t
            val y = ty * t
            val w = min(t, source.width - x)
            val h = min(t, source.height - y)
            Bitmap.createBitmap(source, x, y, w, h).asImageBitmap()
        }
    }
}

/**
 * Half-resolution levels of a document bitmap, built lazily in the background, so zoomed-out views
 * draw few tiles. Level 0 is the document bitmap itself.
 */
class TilePyramid(val source: Bitmap) {
    val maxLevel: Int = run {
        var l = 0
        var m = max(source.width, source.height)
        while (m / 2 >= 256) { m /= 2; l++ }
        l
    }

    private val lock = Any()
    private val bitmaps = arrayOfNulls<Bitmap>(maxLevel + 1).also { it[0] = source }
    private val caches = arrayOfNulls<TileCache>(maxLevel + 1)

    /** Incremented when a new level becomes available, so drawing can pick it up. */
    var readyVersion by mutableIntStateOf(0)
        private set

    fun bestLevel(wanted: Int): Int = synchronized(lock) {
        var l = min(wanted, maxLevel)
        while (l > 0 && bitmaps[l] == null) l--
        l
    }

    fun levelBitmap(level: Int): Bitmap = synchronized(lock) { bitmaps[level]!! }

    fun cache(level: Int): TileCache = synchronized(lock) {
        caches[level] ?: TileCache(bitmaps[level]!!).also { caches[level] = it }
    }

    suspend fun ensureLevel(level: Int) {
        val target = min(level, maxLevel)
        if (target <= 0) return
        withContext(Dispatchers.Default) {
            for (l in 1..target) {
                if (synchronized(lock) { bitmaps[l] != null }) continue
                val prev = synchronized(lock) { bitmaps[l - 1]!! }
                val next = Bitmap.createScaledBitmap(prev, max(1, prev.width / 2), max(1, prev.height / 2), true)
                synchronized(lock) { bitmaps[l] = next }
                withContext(Dispatchers.Main) { readyVersion++ }
            }
        }
    }

    companion object {
        /** Pyramid level whose pixels are still at least one screen pixel at view scale [scale]. */
        fun levelFor(scale: Float, maxLevel: Int): Int =
            if (scale >= 1f) 0 else min(maxLevel, (ln(1f / scale) / ln(2f)).toInt())
    }
}
