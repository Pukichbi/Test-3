package app.nupixel.ui.canvas

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import app.nupixel.core.TileGrid
import app.nupixel.core.ViewTransform
import app.nupixel.render.TilePyramid
import app.nupixel.ui.theme.LocalNx




/**
 * Draws only the document: transparency checkerboard + image tiles. No UI chrome here —
 * grid, guides and outlines live in [OverlayLayer].
 */
@Composable
fun DocumentLayer(bitmap: Bitmap, view: ViewTransform, modifier: Modifier = Modifier) {
    val nx = LocalNx.current
    val pyramid = remember(bitmap) { TilePyramid(bitmap) }
    val paint = remember { Paint().apply { isAntiAlias = false } }
    val wanted = TilePyramid.levelFor(view.scale, pyramid.maxLevel)

    LaunchedEffect(pyramid, wanted) { pyramid.ensureLevel(wanted) }

    Canvas(modifier.fillMaxSize()) {
        pyramid.readyVersion // read so a newly built level triggers a redraw
        val v = view
        val level = pyramid.bestLevel(wanted)
        val lb = pyramid.levelBitmap(level)
        val sx = bitmap.width.toFloat() / lb.width
        val sy = bitmap.height.toFloat() / lb.height

        val corners = listOf(
            v.docToScreen(0f, 0f), v.docToScreen(bitmap.width.toFloat(), 0f),
            v.docToScreen(bitmap.width.toFloat(), bitmap.height.toFloat()), v.docToScreen(0f, bitmap.height.toFloat()),
        )
        val docPath = Path().apply {
            moveTo(corners[0].x, corners[0].y)
            for (i in 1..3) lineTo(corners[i].x, corners[i].y)
            close()
        }
        clipPath(docPath) {
            drawChecker(nx.checkerLight, nx.checkerDark)
            paint.filterQuality = if (v.scale >= 2f) FilterQuality.None else FilterQuality.Medium
            withTransform({
                translate(v.offsetX, v.offsetY)
                rotate(Math.toDegrees(v.rotation.toDouble()).toFloat(), Offset.Zero)
                scale(v.scale, v.scale, Offset.Zero)
                scale(sx, sy, Offset.Zero)
            }) {
                val levelView = ViewTransform(v.scale * sx, v.offsetX, v.offsetY, v.rotation)
                val range = TileGrid.visible(levelView, size.width, size.height, lb.width, lb.height)
                if (!range.isEmpty) {
                    val cache = pyramid.cache(level)
                    drawIntoCanvas { canvas ->
                        for (ty in range.y0..range.y1) {
                            for (tx in range.x0..range.x1) {
                                val t = cache.tile(tx, ty)
                                val tileSize = IntSize(t.width, t.height)
                                canvas.drawImageRect(
                                    t, IntOffset.Zero, tileSize,
                                    IntOffset(tx * TileGrid.TILE, ty * TileGrid.TILE), tileSize, paint,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Screen-aligned checkerboard over the whole drawing area (the caller clips it to the document). */
private fun DrawScope.drawChecker(light: Color, dark: Color) {
    drawRect(light, Offset.Zero, size)
    val cell = 12.dp.toPx()
    var row = 0
    var y = 0f
    while (y < size.height) {
        var col = 0
        var x = 0f
        while (x < size.width) {
            if ((row + col) % 2 != 0) drawRect(dark, Offset(x, y), Size(cell, cell))
            col++
            x += cell
        }
        row++
        y += cell
    }
}
