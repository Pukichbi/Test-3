package app.nupixel.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.Rect
import android.graphics.RectF
import app.nupixel.tools.Floating
import app.nupixel.tools.Selection
import java.nio.ByteBuffer
import kotlin.math.ceil
import kotlin.math.floor

object SelectionOps {
    fun rectSelection(l: Float, t: Float, r: Float, b: Float): Selection {
        val path = Path().apply { addRect(l, t, r, b, Path.Direction.CW) }
        return Selection(path, RectF(l, t, r, b))
    }

    fun polygonSelection(points: List<Pair<Float, Float>>): Selection {
        val path = Path()
        points.forEachIndexed { i, p -> if (i == 0) path.moveTo(p.first, p.second) else path.lineTo(p.first, p.second) }
        path.close()
        val b = RectF()
        path.computeBounds(b, true)
        return Selection(path, b)
    }

    /** Integer document rectangle of the selection, clipped to the canvas; null if empty. */
    fun clippedBounds(sel: Selection, w: Int, h: Int): Rect? {
        val r = Rect(floor(sel.bounds.left).toInt(), floor(sel.bounds.top).toInt(), ceil(sel.bounds.right).toInt(), ceil(sel.bounds.bottom).toInt())
        return if (r.intersect(0, 0, w, h) && r.width() > 0 && r.height() > 0) r else null
    }

    /** Selection coverage per pixel (index = y * w + x), 0 outside. */
    fun mask(path: Path, w: Int, h: Int): ByteArray {
        val a8 = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
        Canvas(a8).drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        val rowBytes = a8.rowBytes
        val buf = ByteBuffer.allocate(a8.byteCount)
        a8.copyPixelsToBuffer(buf)
        a8.recycle()
        val raw = buf.array()
        if (rowBytes == w) return raw
        val out = ByteArray(w * h)
        for (y in 0 until h) System.arraycopy(raw, y * rowBytes, out, y * w, w)
        return out
    }

    fun clear(doc: Bitmap, sel: Selection) {
        val c = Canvas(doc)
        c.save(); c.clipPath(sel.path); c.drawColor(0, PorterDuff.Mode.CLEAR); c.restore()
    }

    fun fill(doc: Bitmap, sel: Selection, color: Int) {
        val c = Canvas(doc)
        c.drawPath(sel.path, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
    }

    /** Cuts the selected pixels out of [doc] into a [Floating] object. */
    fun lift(doc: Bitmap, sel: Selection): Floating? {
        val b = clippedBounds(sel, doc.width, doc.height) ?: return null
        val fb = Bitmap.createBitmap(b.width(), b.height(), Bitmap.Config.ARGB_8888)
        val c = Canvas(fb)
        c.translate(-b.left.toFloat(), -b.top.toFloat())
        c.save(); c.clipPath(sel.path); c.drawBitmap(doc, 0f, 0f, null); c.restore()
        clear(doc, sel)
        return Floating(fb, b, b.exactCenterX(), b.exactCenterY())
    }

    fun floatingMatrix(f: Floating): Matrix = Matrix().apply {
        postTranslate(-f.bitmap.width / 2f, -f.bitmap.height / 2f)
        postScale(f.scale, f.scale)
        postRotate(f.rotation)
        postTranslate(f.cx, f.cy)
    }

    /** Draws the floating pixels back into the document. Returns the touched rectangle. */
    fun drawFloating(doc: Bitmap, f: Floating): Rect {
        Canvas(doc).drawBitmap(f.bitmap, floatingMatrix(f), Paint(Paint.FILTER_BITMAP_FLAG))
        return floatingBounds(f)
    }

    fun floatingBounds(f: Floating): Rect {
        val r = RectF(0f, 0f, f.bitmap.width.toFloat(), f.bitmap.height.toFloat())
        floatingMatrix(f).mapRect(r)
        return Rect(floor(r.left).toInt() - 1, floor(r.top).toInt() - 1, ceil(r.right).toInt() + 1, ceil(r.bottom).toInt() + 1)
    }

    /** Selection matching the (transformed) outline of the floating pixels. */
    fun floatingSelection(f: Floating): Selection {
        val path = Path().apply { addRect(0f, 0f, f.bitmap.width.toFloat(), f.bitmap.height.toFloat(), Path.Direction.CW) }
        path.transform(floatingMatrix(f))
        val b = RectF()
        path.computeBounds(b, true)
        return Selection(path, b)
    }
}
