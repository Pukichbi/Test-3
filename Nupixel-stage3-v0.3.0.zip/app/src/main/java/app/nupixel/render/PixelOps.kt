package app.nupixel.render

import android.graphics.Bitmap
import android.graphics.Rect
import app.nupixel.core.FloodFill
import app.nupixel.tools.Selection

/** Whole-bitmap pixel operations; call from a background thread. Return the changed rectangle or null. */
object PixelOps {
    private class Region(val px: IntArray, val set: java.util.BitSet, val w: Int, val h: Int)

    private fun findRegion(bmp: Bitmap, x: Int, y: Int, tol: Int, contiguous: Boolean, sel: Selection?): Region? {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val mask = sel?.let { SelectionOps.mask(it.path, w, h) }
        val set = FloodFill.region(px, w, h, x, y, tol, contiguous, mask)
        return if (set.isEmpty) null else Region(px, set, w, h)
    }

    private fun apply(bmp: Bitmap, r: Region, change: (Int) -> Int): Rect {
        var minX = r.w; var minY = r.h; var maxX = -1; var maxY = -1
        var i = r.set.nextSetBit(0)
        while (i >= 0) {
            r.px[i] = change(r.px[i])
            val x = i % r.w
            val y = i / r.w
            if (x < minX) minX = x
            if (x > maxX) maxX = x
            if (y < minY) minY = y
            if (y > maxY) maxY = y
            i = r.set.nextSetBit(i + 1)
        }
        bmp.setPixels(r.px, 0, r.w, 0, 0, r.w, r.h)
        return Rect(minX, minY, maxX + 1, maxY + 1)
    }

    fun floodFill(bmp: Bitmap, x: Int, y: Int, color: Int, opacity: Float, tol: Int, contiguous: Boolean, sel: Selection?): Rect? {
        val r = findRegion(bmp, x, y, tol, contiguous, sel) ?: return null
        return apply(bmp, r) { FloodFill.over(it, color or 0xFF000000.toInt(), opacity) }
    }

    /** Makes the matching background colour transparent. */
    fun removeColor(bmp: Bitmap, x: Int, y: Int, tol: Int, contiguous: Boolean, sel: Selection?): Rect? {
        val r = findRegion(bmp, x, y, tol, contiguous, sel) ?: return null
        return apply(bmp, r) { 0 }
    }
}
