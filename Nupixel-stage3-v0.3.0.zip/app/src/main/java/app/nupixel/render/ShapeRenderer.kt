package app.nupixel.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import app.nupixel.tools.ShapeDraft
import app.nupixel.tools.Tool
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object ShapeRenderer {
    fun normalized(d: ShapeDraft) = RectF(min(d.x0, d.x1), min(d.y0, d.y1), max(d.x0, d.x1), max(d.y0, d.y1))

    /** Draws a finished shape and returns the document rectangle it touched. */
    fun draw(canvas: Canvas, d: ShapeDraft, color: Int, opacity: Float, strokeWidth: Float, filled: Boolean): Rect {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = (color and 0x00FFFFFF) or ((opacity * 255f).roundToInt().coerceIn(0, 255) shl 24)
            style = if (filled && d.tool != Tool.LINE) Paint.Style.FILL else Paint.Style.STROKE
            this.strokeWidth = strokeWidth
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val r = normalized(d)
        when (d.tool) {
            Tool.LINE -> canvas.drawLine(d.x0, d.y0, d.x1, d.y1, p)
            Tool.RECT -> canvas.drawRect(r, p)
            else -> canvas.drawOval(r, p)
        }
        val pad = strokeWidth + 2f
        return Rect(floor(r.left - pad).toInt(), floor(r.top - pad).toInt(), ceil(r.right + pad).toInt(), ceil(r.bottom + pad).toInt())
    }
}
