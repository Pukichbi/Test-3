package app.nupixel.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import app.nupixel.core.StampWalker
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt

object BrushStamp {
    /** Round soft/hard brush tip. Colour alpha is ignored; opacity is applied per stroke. */
    fun create(diameter: Int, hardness: Float, color: Int): Bitmap {
        val d = max(1, diameter)
        val bmp = Bitmap.createBitmap(d, d, Bitmap.Config.ARGB_8888)
        val r = d / 2f
        val rgb = color and 0x00FFFFFF
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        if (hardness >= 0.99f) {
            p.color = rgb or 0xFF000000.toInt()
        } else {
            val h = hardness.coerceIn(0.01f, 0.98f)
            p.shader = RadialGradient(
                r, r, r,
                intArrayOf(rgb or 0xFF000000.toInt(), rgb or 0xFF000000.toInt(), rgb),
                floatArrayOf(0f, h, 1f), Shader.TileMode.CLAMP,
            )
        }
        Canvas(bmp).drawCircle(r, r, r, p)
        return bmp
    }
}

/**
 * One brush or eraser stroke. Stamps go into [layer] (so overlapping stamps never exceed the stroke's
 * own opacity); after every step the changed region of [doc] is rebuilt as snapshot + layer * opacity.
 */
class StrokeRenderer(
    private val doc: Bitmap,
    private val snapshot: Bitmap,
    private val layer: Bitmap,
    private val stamp: Bitmap,
    diameter: Float,
    opacity: Float,
    private val eraser: Boolean,
    private val clip: Path?,
) {
    private val docCanvas = Canvas(doc)
    private val layerCanvas = Canvas(layer)
    private val walker = StampWalker(max(1f, diameter * 0.1f))
    private val radius = stamp.width / 2f
    private val stampPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val restorePaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC) }
    private val clearPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
    private val compositePaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        alpha = (opacity * 255f).roundToInt().coerceIn(1, 255)
        if (eraser) xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }
    private val step = RectF()
    private var stepEmpty = true
    private val total = Rect()
    private var totalEmpty = true

    private fun stampAt(x: Float, y: Float) {
        layerCanvas.drawBitmap(stamp, x - radius, y - radius, stampPaint)
        val r = RectF(x - radius - 1, y - radius - 1, x + radius + 1, y + radius + 1)
        if (stepEmpty) { step.set(r); stepEmpty = false } else step.union(r)
    }

    /** Applies the pending stamps to the document. Returns the changed rectangle, or null. */
    private fun flush(): Rect? {
        if (stepEmpty) return null
        stepEmpty = true
        val r = Rect(floor(step.left).toInt(), floor(step.top).toInt(), ceil(step.right).toInt(), ceil(step.bottom).toInt())
        if (!r.intersect(0, 0, doc.width, doc.height)) return null
        docCanvas.save()
        docCanvas.clipRect(r)
        docCanvas.drawBitmap(snapshot, 0f, 0f, restorePaint)
        if (clip != null) docCanvas.clipPath(clip)
        docCanvas.drawBitmap(layer, 0f, 0f, compositePaint)
        docCanvas.restore()
        if (totalEmpty) { total.set(r); totalEmpty = false } else total.union(r)
        return r
    }

    fun begin(x: Float, y: Float): Rect? { walker.begin(x, y, ::stampAt); return flush() }
    fun moveTo(x: Float, y: Float): Rect? { walker.moveTo(x, y, ::stampAt); return flush() }

    /** Finishes the stroke; returns the whole changed rectangle (or null if nothing changed). */
    fun end(): Rect? {
        clearLayer()
        return if (totalEmpty) null else Rect(total)
    }

    /** Puts the document back as it was before the stroke. */
    fun cancel(): Rect? {
        if (totalEmpty) { clearLayer(); return null }
        docCanvas.save()
        docCanvas.clipRect(total)
        docCanvas.drawBitmap(snapshot, 0f, 0f, restorePaint)
        docCanvas.restore()
        clearLayer()
        return Rect(total)
    }

    private fun clearLayer() {
        if (!totalEmpty) layerCanvas.drawRect(Rect(total), clearPaint)
    }
}
