package app.nupixel.core

import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

data class Point(val x: Float, val y: Float)
data class Bounds(val left: Float, val top: Float, val right: Float, val bottom: Float)

/**
 * Maps document coordinates (image pixels) to screen coordinates (view pixels):
 * screen = offset + scale * R(rotation) * doc. [rotation] is in radians, clockwise on screen.
 * Pure Kotlin so it can be unit-tested on the JVM.
 */
data class ViewTransform(
    val scale: Float = 1f,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val rotation: Float = 0f,
) {
    fun docToScreen(x: Float, y: Float): Point {
        val c = cos(rotation)
        val s = sin(rotation)
        return Point(scale * (x * c - y * s) + offsetX, scale * (x * s + y * c) + offsetY)
    }

    fun screenToDoc(sx: Float, sy: Float): Point {
        val c = cos(rotation)
        val s = sin(rotation)
        val dx = sx - offsetX
        val dy = sy - offsetY
        return Point((dx * c + dy * s) / scale, (-dx * s + dy * c) / scale)
    }

    fun panBy(dx: Float, dy: Float) = copy(offsetX = offsetX + dx, offsetY = offsetY + dy)

    /** Zoom by [factor] keeping the document point under ([focusX], [focusY]) fixed on screen. */
    fun zoomAround(focusX: Float, focusY: Float, factor: Float): ViewTransform {
        val newScale = (scale * factor).coerceIn(MIN_SCALE, MAX_SCALE)
        val applied = newScale / scale
        return copy(
            scale = newScale,
            offsetX = focusX - (focusX - offsetX) * applied,
            offsetY = focusY - (focusY - offsetY) * applied,
        )
    }

    /** Rotate the view by [delta] radians around a screen point, which stays fixed. */
    fun rotateAround(focusX: Float, focusY: Float, delta: Float): ViewTransform {
        val c = cos(delta)
        val s = sin(delta)
        val rx = offsetX - focusX
        val ry = offsetY - focusY
        return copy(
            rotation = rotation + delta,
            offsetX = focusX + rx * c - ry * s,
            offsetY = focusY + rx * s + ry * c,
        )
    }

    /** One gesture step: zoom, rotate and pan around the gesture centroid. */
    fun transformBy(focusX: Float, focusY: Float, panX: Float, panY: Float, zoom: Float, rotationDelta: Float): ViewTransform =
        zoomAround(focusX, focusY, zoom).rotateAround(focusX, focusY, rotationDelta).panBy(panX, panY)

    /** Keep scale and rotation; put the document center in the middle of the view. */
    fun centerOn(viewW: Float, viewH: Float, docW: Float, docH: Float): ViewTransform {
        val c = docToScreen(docW / 2f, docH / 2f)
        return panBy(viewW / 2f - c.x, viewH / 2f - c.y)
    }

    /** Axis-aligned bounds, in document coordinates, of the visible viewport. */
    fun viewportBounds(viewW: Float, viewH: Float): Bounds {
        val p = listOf(screenToDoc(0f, 0f), screenToDoc(viewW, 0f), screenToDoc(0f, viewH), screenToDoc(viewW, viewH))
        return Bounds(p.minOf { it.x }, p.minOf { it.y }, p.maxOf { it.x }, p.maxOf { it.y })
    }

    companion object {
        const val MIN_SCALE = 0.02f
        const val MAX_SCALE = 64f

        /** Scale and center the document (unrotated) inside the view with [padding] px on every side. */
        fun fit(viewW: Float, viewH: Float, docW: Float, docH: Float, padding: Float = 0f): ViewTransform {
            val availW = (viewW - 2 * padding).coerceAtLeast(1f)
            val availH = (viewH - 2 * padding).coerceAtLeast(1f)
            val s = min(availW / docW, availH / docH).coerceIn(MIN_SCALE, MAX_SCALE)
            return ViewTransform(s, (viewW - docW * s) / 2f, (viewH - docH * s) / 2f)
        }
    }
}
