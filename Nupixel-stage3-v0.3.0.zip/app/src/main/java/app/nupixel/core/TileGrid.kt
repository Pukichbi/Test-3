package app.nupixel.core

import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** Inclusive tile index range; empty when x1 < x0 or y1 < y0. */
data class TileRange(val x0: Int, val x1: Int, val y0: Int, val y1: Int) {
    val isEmpty get() = x1 < x0 || y1 < y0
}

object TileGrid {
    const val TILE = 512

    /** Tiles of a [docW] x [docH] raster that intersect the viewport (conservative for rotated views). */
    fun visible(view: ViewTransform, viewW: Float, viewH: Float, docW: Int, docH: Int, tile: Int = TILE, margin: Float = 4f): TileRange {
        val b = view.viewportBounds(viewW, viewH)
        val l = max(b.left - margin, 0f)
        val t = max(b.top - margin, 0f)
        val r = min(b.right + margin, docW.toFloat())
        val btm = min(b.bottom + margin, docH.toFloat())
        if (r <= l || btm <= t) return TileRange(0, -1, 0, -1)
        return TileRange(
            x0 = floor(l / tile).toInt(),
            x1 = min(ceil(r / tile).toInt() - 1, (docW - 1) / tile),
            y0 = floor(t / tile).toInt(),
            y1 = min(ceil(btm / tile).toInt() - 1, (docH - 1) / tile),
        )
    }
}
