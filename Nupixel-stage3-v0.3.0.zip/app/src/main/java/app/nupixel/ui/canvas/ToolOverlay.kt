package app.nupixel.ui.canvas

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import app.nupixel.core.ViewTransform
import app.nupixel.render.SelectionOps
import app.nupixel.render.ShapeRenderer
import app.nupixel.render.TextRenderer
import app.nupixel.tools.Selection
import app.nupixel.tools.Tool
import app.nupixel.tools.ToolController
import app.nupixel.tools.ToolSettings

/** Transient tool visuals in document space: selection outline, shape preview, lasso, floating pixels, text. */
@Composable
fun ToolOverlay(view: ViewTransform, controller: ToolController, selection: Selection?, settings: ToolSettings) {
    val bitmapPaint = remember { Paint(Paint.FILTER_BITMAP_FLAG) }
    Canvas(Modifier.fillMaxSize()) {
        val v = view
        withTransform({
            translate(v.offsetX, v.offsetY)
            rotate(Math.toDegrees(v.rotation.toDouble()).toFloat(), Offset.Zero)
            scale(v.scale, v.scale, Offset.Zero)
        }) {
            val px = 1f / v.scale // one screen pixel in document units

            controller.floating?.let { f ->
                drawIntoCanvas { c ->
                    val nc = c.nativeCanvas
                    nc.save()
                    nc.concat(SelectionOps.floatingMatrix(f))
                    nc.drawBitmap(f.bitmap, 0f, 0f, bitmapPaint)
                    nc.restore()
                }
                drawAnts(SelectionOps.floatingSelection(f).path.asComposePath(), px)
            }

            if (controller.floating == null) selection?.let { drawAnts(it.path.asComposePath(), px) }

            controller.draft?.let { d ->
                val r = ShapeRenderer.normalized(d)
                when (d.tool) {
                    Tool.SELECT_RECT -> drawAnts(Path().apply { addRect(androidx.compose.ui.geometry.Rect(r.left, r.top, r.right, r.bottom)) }, px)
                    Tool.LINE -> drawLine(
                        Color(settings.color).copy(alpha = settings.shapeOpacity), Offset(d.x0, d.y0), Offset(d.x1, d.y1),
                        strokeWidth = settings.shapeStroke, cap = StrokeCap.Round,
                    )
                    Tool.RECT -> drawRect(
                        Color(settings.color).copy(alpha = settings.shapeOpacity), Offset(r.left, r.top), Size(r.width(), r.height()),
                        style = if (settings.shapeFilled) Fill else Stroke(settings.shapeStroke),
                    )
                    else -> drawOval(
                        Color(settings.color).copy(alpha = settings.shapeOpacity), Offset(r.left, r.top), Size(r.width(), r.height()),
                        style = if (settings.shapeFilled) Fill else Stroke(settings.shapeStroke),
                    )
                }
            }

            val points = controller.lasso
            if (points.size >= 2) {
                val p = Path().apply {
                    moveTo(points[0].first, points[0].second)
                    for (i in 1 until points.size) lineTo(points[i].first, points[i].second)
                }
                drawAnts(p, px)
            }

            controller.text?.let { t ->
                drawIntoCanvas { c -> TextRenderer.draw(c.nativeCanvas, t) }
                val b = TextRenderer.bounds(t)
                drawRect(
                    Color(0xFF22D3EE), Offset(b.left, b.top), Size(b.width(), b.height()),
                    style = Stroke(1.5f * px, pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f * px, 4f * px))),
                )
            }
        }
    }
}

/** Dark outline with a dashed white line on top, readable on any image. */
private fun DrawScope.drawAnts(path: Path, px: Float) {
    drawPath(path, Color.Black.copy(alpha = 0.75f), style = Stroke(width = 2f * px))
    drawPath(path, Color.White, style = Stroke(width = 2f * px, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f * px, 6f * px))))
}
