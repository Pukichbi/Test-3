package app.nupixel.ui.screens

import android.graphics.Color as AColor
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.nupixel.R
import app.nupixel.core.Limits
import app.nupixel.ui.components.NxButton
import app.nupixel.ui.components.NxNumberField
import app.nupixel.ui.components.NxSectionLabel
import app.nupixel.ui.components.NxSegmented
import kotlin.math.roundToInt

/** Crop, canvas size and resolution. Each action replaces the whole document bitmap. */
@Composable
fun CanvasSheet(
    docW: Int,
    docH: Int,
    onCrop: (x: Int, y: Int, w: Int, h: Int) -> Unit,
    onResizeCanvas: (w: Int, h: Int, anchorX: Int, anchorY: Int, fill: Int) -> Unit,
    onResample: (w: Int, h: Int) -> Unit,
) {
    var tab by remember { mutableStateOf("crop") }
    val cs = MaterialTheme.colorScheme

    Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 16.dp).navigationBarsPadding().verticalScroll(rememberScrollState())) {
        Text(stringResource(R.string.editor_canvas), style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        NxSegmented(
            options = listOf(
                "crop" to stringResource(R.string.canvas_tab_crop),
                "size" to stringResource(R.string.canvas_tab_size),
                "resample" to stringResource(R.string.canvas_tab_resample),
            ),
            selected = tab, onSelect = { tab = it },
        )
        Text(
            stringResource(if (tab == "resample") R.string.resample_note else R.string.canvas_note),
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp),
        )

        when (tab) {
            "crop" -> CropTab(docW, docH, onCrop)
            "size" -> SizeTab(docW, docH, onResizeCanvas)
            else -> ResampleTab(docW, docH, onResample)
        }
    }
}

@Composable
private fun CropTab(docW: Int, docH: Int, onCrop: (Int, Int, Int, Int) -> Unit) {
    var xs by remember(docW, docH) { mutableStateOf("0") }
    var ys by remember(docW, docH) { mutableStateOf("0") }
    var ws by remember(docW, docH) { mutableStateOf(docW.toString()) }
    var hs by remember(docW, docH) { mutableStateOf(docH.toString()) }
    val x = xs.toIntOrNull()
    val y = ys.toIntOrNull()
    val w = ws.toIntOrNull()
    val h = hs.toIntOrNull()
    val valid = x != null && y != null && w != null && h != null && w >= 1 && h >= 1 && x >= 0 && y >= 0 && x + w <= docW && y + h <= docH

    NxSectionLabel(stringResource(R.string.canvas_tab_crop))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        NxNumberField(xs, { xs = it }, stringResource(R.string.label_x), Modifier.weight(1f))
        NxNumberField(ys, { ys = it }, stringResource(R.string.label_y), Modifier.weight(1f))
    }
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        NxNumberField(ws, { ws = it }, stringResource(R.string.label_width), Modifier.weight(1f))
        NxNumberField(hs, { hs = it }, stringResource(R.string.label_height), Modifier.weight(1f))
    }
    if (!valid) ErrorLine(stringResource(R.string.err_crop_range))
    Spacer(Modifier.height(16.dp))
    NxButton(stringResource(R.string.action_apply), enabled = valid, onClick = { onCrop(x!!, y!!, w!!, h!!) })
}

@Composable
private fun SizeTab(docW: Int, docH: Int, onResize: (Int, Int, Int, Int, Int) -> Unit) {
    var ws by remember(docW, docH) { mutableStateOf(docW.toString()) }
    var hs by remember(docW, docH) { mutableStateOf(docH.toString()) }
    var ax by remember { mutableStateOf(1) }
    var ay by remember { mutableStateOf(1) }
    var bg by remember { mutableStateOf("transparent") }
    val w = ws.toIntOrNull()
    val h = hs.toIntOrNull()
    val valid = w != null && h != null && Limits.fits(w, h)

    NxSectionLabel(stringResource(R.string.canvas_tab_size))
    SizeFields(ws, hs, { ws = it }, { hs = it })
    if (!valid) ErrorLine(sizeError())

    NxSectionLabel(stringResource(R.string.label_anchor))
    AnchorPicker(ax, ay) { x, y -> ax = x; ay = y }

    NxSectionLabel(stringResource(R.string.label_background))
    NxSegmented(
        options = listOf(
            "transparent" to stringResource(R.string.bg_transparent),
            "white" to stringResource(R.string.bg_white),
            "black" to stringResource(R.string.bg_black),
        ),
        selected = bg, onSelect = { bg = it },
    )
    Spacer(Modifier.height(16.dp))
    NxButton(stringResource(R.string.action_apply), enabled = valid, onClick = {
        val fill = when (bg) { "white" -> AColor.WHITE; "black" -> AColor.BLACK; else -> AColor.TRANSPARENT }
        onResize(w!!, h!!, ax, ay, fill)
    })
}

@Composable
private fun ResampleTab(docW: Int, docH: Int, onResample: (Int, Int) -> Unit) {
    var ws by remember(docW, docH) { mutableStateOf(docW.toString()) }
    var hs by remember(docW, docH) { mutableStateOf(docH.toString()) }
    var lock by remember { mutableStateOf(true) }
    val w = ws.toIntOrNull()
    val h = hs.toIntOrNull()
    val valid = w != null && h != null && Limits.fits(w, h) && (w != docW || h != docH)

    NxSectionLabel(stringResource(R.string.canvas_tab_resample))
    SizeFields(
        ws, hs,
        onW = { v ->
            ws = v
            if (lock) v.toIntOrNull()?.let { hs = (it * docH / docW.toFloat()).roundToInt().coerceAtLeast(1).toString() }
        },
        onH = { v ->
            hs = v
            if (lock) v.toIntOrNull()?.let { ws = (it * docW / docH.toFloat()).roundToInt().coerceAtLeast(1).toString() }
        },
    )
    if (w != null && h != null && !Limits.fits(w, h)) ErrorLine(sizeError())
    Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(R.string.label_lock_aspect), Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = lock, onCheckedChange = { lock = it })
    }
    Spacer(Modifier.height(16.dp))
    NxButton(stringResource(R.string.action_apply), enabled = valid, onClick = { onResample(w!!, h!!) })
}

@Composable
private fun SizeFields(ws: String, hs: String, onW: (String) -> Unit, onH: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        NxNumberField(ws, onW, stringResource(R.string.label_width), Modifier.weight(1f))
        NxNumberField(hs, onH, stringResource(R.string.label_height), Modifier.weight(1f))
    }
}

@Composable
private fun sizeError(): String =
    stringResource(R.string.err_size_range, Limits.MAX_SIDE) + " · " + stringResource(R.string.err_size_limit, Limits.maxMegapixels())

@Composable
private fun ErrorLine(text: String) {
    Text(text, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun AnchorPicker(ax: Int, ay: Int, onPick: (Int, Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (y in 0..2) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (x in 0..2) {
                    val on = x == ax && y == ay
                    Surface(
                        onClick = { onPick(x, y) },
                        shape = MaterialTheme.shapes.small,
                        color = if (on) cs.primary.copy(alpha = 0.14f) else cs.surfaceContainerHigh,
                        border = BorderStroke(if (on) 1.5.dp else 1.dp, if (on) cs.primary else cs.outlineVariant),
                        modifier = Modifier.size(48.dp),
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Box(Modifier.size(10.dp).background(if (on) cs.primary else cs.onSurfaceVariant.copy(alpha = 0.5f), CircleShape))
                        }
                    }
                }
            }
        }
    }
}
