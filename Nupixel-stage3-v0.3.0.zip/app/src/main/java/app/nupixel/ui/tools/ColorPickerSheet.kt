package app.nupixel.ui.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.nupixel.R
import app.nupixel.core.ColorMath
import app.nupixel.ui.components.NxSliderRow
import kotlin.math.roundToInt

private val Palette = listOf(
    0xFF000000, 0xFF404040, 0xFF808080, 0xFFBFBFBF, 0xFFFFFFFF, 0xFF7A4A21, 0xFFE11D48, 0xFFF97316,
    0xFFFACC15, 0xFF84CC16, 0xFF16A34A, 0xFF14B8A6, 0xFF22D3EE, 0xFF2F7BFF, 0xFF8B5CF6, 0xFFEC4899,
).map { it.toInt() }

/** HSV sliders, hex entry and a palette. Calls [onColor] live as the colour changes. */
@Composable
fun ColorPickerSheet(initial: Int, onColor: (Int) -> Unit) {
    val start = remember { ColorMath.argbToHsv(initial) }
    var h by remember { mutableFloatStateOf(start[0]) }
    var s by remember { mutableFloatStateOf(start[1]) }
    var v by remember { mutableFloatStateOf(start[2]) }
    var hex by remember { mutableStateOf(String.format("%06X", initial and 0xFFFFFF)) }
    val argb = ColorMath.hsvToArgb(h, s, v)

    fun set(newColor: Int, fromHex: Boolean = false) {
        val hsv = ColorMath.argbToHsv(newColor)
        h = hsv[0]; s = hsv[1]; v = hsv[2]
        if (!fromHex) hex = String.format("%06X", newColor and 0xFFFFFF)
        onColor(newColor or 0xFF000000.toInt())
    }
    fun slid() {
        val c = ColorMath.hsvToArgb(h, s, v)
        hex = String.format("%06X", c and 0xFFFFFF)
        onColor(c)
    }

    Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 16.dp).navigationBarsPadding()) {
        Text(stringResource(R.string.color_title), style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(Color(argb))
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp)),
            )
            OutlinedTextField(
                value = hex,
                onValueChange = { raw ->
                    val t = raw.filter { it.isDigit() || it in 'a'..'f' || it in 'A'..'F' }.take(6).uppercase()
                    hex = t
                    if (t.length == 6) set(0xFF000000.toInt() or t.toInt(16), fromHex = true)
                },
                label = { Text(stringResource(R.string.color_hex)) },
                prefix = { Text("#") },
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
        }
        Spacer(Modifier.height(8.dp))
        NxSliderRow(stringResource(R.string.color_hue), h, 0f..360f, "${h.roundToInt()}°") { h = it; slid() }
        NxSliderRow(stringResource(R.string.color_saturation), s, 0f..1f, "${(s * 100).roundToInt()}%") { s = it; slid() }
        NxSliderRow(stringResource(R.string.color_value), v, 0f..1f, "${(v * 100).roundToInt()}%") { v = it; slid() }
        Spacer(Modifier.height(8.dp))
        for (row in Palette.chunked(8)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                row.forEach { c ->
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                            .clickable { set(c) },
                    )
                }
            }
        }
    }
}
