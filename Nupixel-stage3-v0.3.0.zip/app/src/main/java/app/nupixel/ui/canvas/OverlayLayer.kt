package app.nupixel.ui.canvas

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import app.nupixel.core.Guide
import app.nupixel.core.Point
import app.nupixel.core.ViewTransform
import app.nupixel.ui.theme.LocalNx
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

private val GRID_STEPS = intArrayOf(1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096)

/** Editor aids drawn above the document in screen space: document outline, grid, guides. */
@Composable
fun OverlayLayer(
    docW: Int,
    docH: Int,
    view: ViewTransform,
    showGrid: Boolean,
    showGuides: Boolean,
    guides: List<Guide>,
    modifier: Modifier = Modifier,
) {
    val nx = LocalNx.current
    Canvas(modifier.fillMaxSize()) {
        val v = view
        val hairline = 1.dp.toPx()

        if (showGrid) drawGrid(v, docW, docH, Color(0x55FFFFFF), hairline)

        if (showGuides) {
            guides.forEach { g ->
                val a: Point
                val b: Point
                if (g.vertical) {
                    a = v.docToScreen(g.position.toFloat(), 0f); b = v.docToScreen(g.position.toFloat(), docH.toFloat())
                } else {
                    a = v.docToScreen(0f, g.position.toFloat()); b = v.docToScreen(docW.toFloat(), g.position.toFloat())
                }
                drawLine(nx.brandCyan, Offset(a.x, a.y), Offset(b.x, b.y), strokeWidth = 1.5.dp.toPx())
            }
        }

        val c = listOf(v.docToScreen(0f, 0f), v.docToScreen(docW.toFloat(), 0f), v.docToScreen(docW.toFloat(), docH.toFloat()), v.docToScreen(0f, docH.toFloat()))
        val outline = Path().apply {
            moveTo(c[0].x, c[0].y); for (i in 1..3) lineTo(c[i].x, c[i].y); close()
        }
        drawPath(outline, Color(0x66000000), style = Stroke(width = hairline))
    }
}

private fun DrawScope.drawGrid(v: ViewTransform, docW: Int, docH: Int, color: Color, width: Float) {
    val minPx = 20.dp.toPx()
    val step = GRID_STEPS.firstOrNull { it * v.scale >= minPx } ?: return
    val b = v.viewportBounds(size.width, size.height)
    val x0 = max(0f, b.left)
    val x1 = min(docW.toFloat(), b.right)
    val y0 = max(0f, b.top)
    val y1 = min(docH.toFloat(), b.bottom)
    if (x1 <= x0 || y1 <= y0) return

    var x = (ceil(x0 / step) * step).toInt()
    while (x <= x1) {
        val a = v.docToScreen(x.toFloat(), y0)
        val c = v.docToScreen(x.toFloat(), y1)
        drawLine(color, Offset(a.x, a.y), Offset(c.x, c.y), strokeWidth = width)
        x += step
    }
    var y = (ceil(y0 / step) * step).toInt()
    while (y <= y1) {
        val a = v.docToScreen(x0, y.toFloat())
        val c = v.docToScreen(x1, y.toFloat())
        drawLine(color, Offset(a.x, a.y), Offset(c.x, c.y), strokeWidth = width)
        y += step
    }
}
