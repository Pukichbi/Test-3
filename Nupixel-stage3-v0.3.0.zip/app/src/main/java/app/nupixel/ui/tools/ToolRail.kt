package app.nupixel.ui.tools

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.CheckBoxOutlineBlank
import androidx.compose.material.icons.rounded.Colorize
import androidx.compose.material.icons.rounded.FormatColorFill
import androidx.compose.material.icons.rounded.Gesture
import androidx.compose.material.icons.rounded.HorizontalRule
import androidx.compose.material.icons.rounded.LayersClear
import androidx.compose.material.icons.rounded.OpenWith
import androidx.compose.material.icons.rounded.PanTool
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nupixel.R
import app.nupixel.tools.Tool

private class RailItem(val tool: Tool, val icon: ImageVector, val label: Int)

private val items = listOf(
    RailItem(Tool.VIEW, Icons.Rounded.PanTool, R.string.tool_view),
    RailItem(Tool.BRUSH, Icons.Rounded.Brush, R.string.tool_brush),
    RailItem(Tool.ERASER, Icons.Rounded.LayersClear, R.string.tool_eraser),
    RailItem(Tool.FILL, Icons.Rounded.FormatColorFill, R.string.tool_fill),
    RailItem(Tool.EYEDROPPER, Icons.Rounded.Colorize, R.string.tool_picker),
    RailItem(Tool.MAGIC_ERASER, Icons.Rounded.AutoFixHigh, R.string.tool_bg_remove),
    RailItem(Tool.LINE, Icons.Rounded.HorizontalRule, R.string.tool_line),
    RailItem(Tool.RECT, Icons.Rounded.CheckBoxOutlineBlank, R.string.tool_rect),
    RailItem(Tool.ELLIPSE, Icons.Rounded.RadioButtonUnchecked, R.string.tool_ellipse),
    RailItem(Tool.TEXT, Icons.Rounded.TextFields, R.string.tool_text),
    RailItem(Tool.SELECT_RECT, Icons.Rounded.SelectAll, R.string.tool_select_rect),
    RailItem(Tool.SELECT_FREE, Icons.Rounded.Gesture, R.string.tool_select_free),
    RailItem(Tool.MOVE, Icons.Rounded.OpenWith, R.string.tool_move),
)

/** Horizontally scrolling tool strip. */
@Composable
fun ToolRail(active: Tool, onSelect: (Tool) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 4.dp)) {
        items.forEach { item ->
            val on = item.tool == active
            Surface(
                onClick = { onSelect(item.tool) },
                shape = MaterialTheme.shapes.small,
                color = if (on) cs.primary.copy(alpha = 0.18f) else Color.Transparent,
                contentColor = if (on) cs.primary else cs.onSurfaceVariant,
                modifier = Modifier.width(68.dp).padding(horizontal = 2.dp),
            ) {
                Column(Modifier.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(item.icon, contentDescription = null)
                    Text(stringResource(item.label), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}
