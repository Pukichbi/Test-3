package app.nupixel.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.nupixel.R
import app.nupixel.core.Guide
import app.nupixel.ui.components.NxButton
import app.nupixel.ui.components.NxNumberField
import app.nupixel.ui.components.NxSectionLabel

@Composable
fun GuidesSheet(
    showGrid: Boolean,
    showGuides: Boolean,
    guides: List<Guide>,
    onShowGrid: (Boolean) -> Unit,
    onShowGuides: (Boolean) -> Unit,
    onAdd: (vertical: Boolean, position: Int) -> Unit,
    onAddCenter: () -> Unit,
    onRemove: (Int) -> Unit,
    onClear: () -> Unit,
    onCenterView: () -> Unit,
) {
    var pos by remember { mutableStateOf("") }
    val p = pos.toIntOrNull()
    val cs = MaterialTheme.colorScheme

    Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 16.dp).navigationBarsPadding().verticalScroll(rememberScrollState())) {
        Text(stringResource(R.string.editor_guides), style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        ToggleRow(stringResource(R.string.guides_show_grid), showGrid, onShowGrid)
        ToggleRow(stringResource(R.string.guides_show_guides), showGuides, onShowGuides)

        NxSectionLabel(stringResource(R.string.guides_list))
        if (guides.isEmpty()) {
            Text(stringResource(R.string.guides_none), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
        } else {
            guides.forEachIndexed { i, g ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(if (g.vertical) R.string.guide_item_v else R.string.guide_item_h, g.position),
                        Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge,
                    )
                    IconButton(onClick = { onRemove(i) }) { Icon(Icons.Rounded.Delete, stringResource(R.string.cd_delete), tint = cs.onSurfaceVariant) }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        NxNumberField(pos, { pos = it }, stringResource(R.string.guides_position), Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            NxButton(stringResource(R.string.guides_vertical), { onAdd(true, p!!) }, Modifier.weight(1f), primary = false, enabled = p != null)
            NxButton(stringResource(R.string.guides_horizontal), { onAdd(false, p!!) }, Modifier.weight(1f), primary = false, enabled = p != null)
        }
        Spacer(Modifier.height(8.dp))
        NxButton(stringResource(R.string.guides_center), onAddCenter, primary = false)
        if (guides.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            NxButton(stringResource(R.string.guides_clear), onClear, primary = false)
        }
        Spacer(Modifier.height(16.dp))
        NxButton(stringResource(R.string.guides_center_view), onCenterView)
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
