package app.nupixel.data

import app.nupixel.core.Guide
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

const val CURRENT_FORMAT_VERSION = 1
const val MANIFEST_ENTRY = "manifest.json"
private const val FORMAT_ID = "nupixel-project"

data class LayerEntry(
    val id: String,
    val name: String,
    val type: String, // "raster" in format v1
    val file: String, // entry path inside the .npx archive
    val visible: Boolean = true,
    val opacity: Float = 1f,
)

data class ProjectManifest(
    val formatVersion: Int = CURRENT_FORMAT_VERSION,
    val appVersion: String,
    val name: String,
    val width: Int,
    val height: Int,
    val colorSpace: String = "sRGB",
    val createdAt: Long,
    val modifiedAt: Long,
    val layers: List<LayerEntry>,
    val guides: List<Guide> = emptyList(),
)

open class ProjectFormatException(message: String) : Exception(message)
class ProjectTooNewException(val version: Int) : ProjectFormatException("Project format $version is newer than supported $CURRENT_FORMAT_VERSION")

/** Reads and writes manifest.json; upgrades older format versions step by step. */
object ManifestCodec {
    /** migrations[n] upgrades a version-n document to version n+1. Empty while only v1 exists. */
    private val migrations: Map<Int, (JSONObject) -> JSONObject> = emptyMap()

    fun encode(m: ProjectManifest): String {
        val layers = JSONArray()
        m.layers.forEach {
            layers.put(
                JSONObject()
                    .put("id", it.id).put("name", it.name).put("type", it.type)
                    .put("file", it.file).put("visible", it.visible)
                    .put("opacity", it.opacity.toDouble())
            )
        }
        return JSONObject()
            .put("format", FORMAT_ID)
            .put("formatVersion", m.formatVersion)
            .put("appVersion", m.appVersion)
            .put("name", m.name)
            .put("canvas", JSONObject().put("width", m.width).put("height", m.height).put("colorSpace", m.colorSpace))
            .put("createdAt", m.createdAt)
            .put("modifiedAt", m.modifiedAt)
            .put("layers", layers)
            .put("guides", JSONArray().also { arr ->
                m.guides.forEach { arr.put(JSONObject().put("o", if (it.vertical) "v" else "h").put("p", it.position)) }
            })
            .toString(2)
    }

    fun decode(text: String): ProjectManifest {
        try {
            var json = JSONObject(text)
            if (json.optString("format") != FORMAT_ID) throw ProjectFormatException("Not a Nupixel project")
            var version = json.optInt("formatVersion", -1)
            if (version < 1) throw ProjectFormatException("Missing format version")
            if (version > CURRENT_FORMAT_VERSION) throw ProjectTooNewException(version)
            while (version < CURRENT_FORMAT_VERSION) {
                val step = migrations[version] ?: throw ProjectFormatException("No migration from v$version")
                json = step(json)
                version++
                json.put("formatVersion", version)
            }
            val canvas = json.getJSONObject("canvas")
            val width = canvas.getInt("width")
            val height = canvas.getInt("height")
            if (width < 1 || height < 1) throw ProjectFormatException("Invalid canvas size")
            val arr = json.getJSONArray("layers")
            val layers = (0 until arr.length()).map {
                val l = arr.getJSONObject(it)
                val file = l.getString("file")
                if (!file.startsWith("layers/") || file.contains("..")) throw ProjectFormatException("Invalid layer path")
                LayerEntry(
                    id = l.getString("id"), name = l.getString("name"), type = l.getString("type"),
                    file = file, visible = l.optBoolean("visible", true),
                    opacity = l.optDouble("opacity", 1.0).toFloat().coerceIn(0f, 1f),
                )
            }
            if (layers.isEmpty()) throw ProjectFormatException("Project has no layers")
            val guides = json.optJSONArray("guides")?.let { ga ->
                (0 until ga.length()).map {
                    val g = ga.getJSONObject(it)
                    Guide(vertical = g.getString("o") == "v", position = g.getInt("p"))
                }
            } ?: emptyList()
            return ProjectManifest(
                formatVersion = version,
                appVersion = json.optString("appVersion", ""),
                name = json.optString("name", ""),
                width = width, height = height,
                colorSpace = canvas.optString("colorSpace", "sRGB"),
                createdAt = json.optLong("createdAt", 0L),
                modifiedAt = json.optLong("modifiedAt", 0L),
                layers = layers,
                guides = guides,
            )
        } catch (e: JSONException) {
            throw ProjectFormatException("Malformed manifest: ${e.message}")
        }
    }
}
