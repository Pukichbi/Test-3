package app.nupixel.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import app.nupixel.core.Limits
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class ProjectInfo(
    val id: String,
    val name: String,
    val width: Int,
    val height: Int,
    val modifiedAt: Long,
    val sizeBytes: Long,
    val thumbnail: File?,
)

class LoadedProject(val id: String, val manifest: ProjectManifest, val bitmap: Bitmap)

/**
 * Projects live in filesDir/projects as `<id>.npx` (zip: manifest.json + layers/*.png).
 * Saving writes a temp file, verifies it, then swaps it in keeping a .bak until the swap succeeds,
 * so an interrupted save never destroys the previous version.
 */
class ProjectStore(context: Context) {
    private val dir = File(context.filesDir, "projects").apply { mkdirs() }

    init { recoverInterruptedSaves() }

    private fun file(id: String) = File(dir, "$id.npx")
    private fun thumbFile(id: String) = File(dir, "$id.thumb.jpg")

    private fun recoverInterruptedSaves() {
        dir.listFiles().orEmpty().forEach { f ->
            when {
                f.name.endsWith(".npx.tmp") -> f.delete()
                f.name.endsWith(".npx.bak") -> {
                    val target = File(dir, f.name.removeSuffix(".bak"))
                    if (target.exists()) f.delete() else f.renameTo(target)
                }
            }
        }
    }

    fun newId(): String = UUID.randomUUID().toString()

    fun list(): List<ProjectInfo> =
        dir.listFiles { f -> f.name.endsWith(".npx") }.orEmpty()
            .mapNotNull { readInfo(it) }
            .sortedByDescending { it.modifiedAt }

    private fun readInfo(f: File): ProjectInfo? = try {
        ZipFile(f).use { zip ->
            val entry = zip.getEntry(MANIFEST_ENTRY)
            if (entry == null) null else {
                val m = ManifestCodec.decode(zip.getInputStream(entry).bufferedReader().readText())
                val id = f.name.removeSuffix(".npx")
                ProjectInfo(id, m.name, m.width, m.height, m.modifiedAt, f.length(), thumbFile(id).takeIf { it.exists() })
            }
        }
    } catch (e: Exception) {
        null
    }

    @Throws(IOException::class)
    fun save(id: String, manifest: ProjectManifest, bitmap: Bitmap) {
        val target = file(id)
        val tmp = File(dir, "$id.npx.tmp")
        val bak = File(dir, "$id.npx.bak")
        try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { zip ->
                zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
                zip.write(ManifestCodec.encode(manifest).toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                zip.setLevel(Deflater.NO_COMPRESSION) // PNG is already compressed
                zip.putNextEntry(ZipEntry(manifest.layers.first().file))
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, zip)) throw IOException("PNG encode failed")
                zip.closeEntry()
            }
            if (readInfo(tmp) == null) throw IOException("Saved file failed verification")
            if (target.exists()) {
                bak.delete()
                if (!target.renameTo(bak)) throw IOException("Cannot move previous version")
            }
            if (!tmp.renameTo(target)) {
                if (bak.exists()) bak.renameTo(target)
                throw IOException("Cannot move new version into place")
            }
            bak.delete()
        } finally {
            if (tmp.exists()) tmp.delete()
        }
        writeThumbnail(id, bitmap)
    }

    fun writeThumbnail(id: String, bitmap: Bitmap) {
        try {
            val longest = maxOf(bitmap.width, bitmap.height)
            val s = 256f / longest
            val w = (bitmap.width * s).toInt().coerceAtLeast(1)
            val h = (bitmap.height * s).toInt().coerceAtLeast(1)
            val small = Bitmap.createScaledBitmap(bitmap, w, h, true)
            val flat = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            android.graphics.Canvas(flat).apply {
                drawColor(0xFF2A3350.toInt())
                drawBitmap(small, 0f, 0f, null)
            }
            FileOutputStream(thumbFile(id)).use { flat.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            if (small !== bitmap) small.recycle()
            flat.recycle()
        } catch (_: Exception) {
            // Thumbnails are cosmetic; never fail a save because of them.
        }
    }

    @Throws(ProjectFormatException::class, IOException::class)
    fun load(id: String): LoadedProject {
        val f = file(id)
        try {
            ZipFile(f).use { zip ->
                val me = zip.getEntry(MANIFEST_ENTRY) ?: throw ProjectFormatException("No manifest")
                val manifest = ManifestCodec.decode(zip.getInputStream(me).bufferedReader().readText())
                if (manifest.width > Limits.MAX_SIDE || manifest.height > Limits.MAX_SIDE ||
                    manifest.width.toLong() * manifest.height > Limits.maxPixels()
                ) throw OutOfMemoryError("Project larger than this device can hold")
                val layer = manifest.layers.first()
                val le = zip.getEntry(layer.file) ?: throw ProjectFormatException("Missing layer data")
                val opts = BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                    inMutable = true
                }
                val bmp = zip.getInputStream(le).use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: throw ProjectFormatException("Layer image is unreadable")
                if (bmp.width != manifest.width || bmp.height != manifest.height) {
                    throw ProjectFormatException("Layer size does not match canvas")
                }
                return LoadedProject(id, manifest, bmp)
            }
        } catch (e: java.util.zip.ZipException) {
            throw ProjectFormatException("Not a valid project archive")
        }
    }

    /** Copies an external .npx into the library under a new id after validating its manifest. */
    @Throws(ProjectFormatException::class, IOException::class)
    fun importFile(input: InputStream): String {
        val id = newId()
        val tmp = File(dir, "$id.npx.tmp")
        try {
            FileOutputStream(tmp).use { input.copyTo(it) }
            if (!isValidArchive(tmp)) throw ProjectFormatException("Not a valid project")
            if (!tmp.renameTo(file(id))) throw IOException("Cannot store project")
        } finally {
            if (tmp.exists()) tmp.delete()
        }
        return id
    }

    private fun isValidArchive(f: File): Boolean = try {
        ZipFile(f).use { zip ->
            val e = zip.getEntry(MANIFEST_ENTRY)
            if (e == null) false else {
                ManifestCodec.decode(zip.getInputStream(e).bufferedReader().readText())
                true
            }
        }
    } catch (e: ProjectTooNewException) {
        throw e
    } catch (e: Exception) {
        false
    }

    @Throws(IOException::class)
    fun copyTo(id: String, out: OutputStream) {
        file(id).inputStream().use { it.copyTo(out) }
    }

    fun delete(id: String): Boolean {
        val ok = !file(id).exists() || file(id).delete()
        thumbFile(id).delete()
        return ok
    }
}
