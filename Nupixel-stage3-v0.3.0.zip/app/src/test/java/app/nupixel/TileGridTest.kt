package app.nupixel

import app.nupixel.core.TileGrid
import app.nupixel.core.ViewTransform
import app.nupixel.render.TilePyramid
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TileGridTest {
    @Test fun visibleTilesAtOrigin() {
        val r = TileGrid.visible(ViewTransform(), 1000f, 1000f, 4096, 4096)
        assertEquals(0, r.x0); assertEquals(1, r.x1)
        assertEquals(0, r.y0); assertEquals(1, r.y1)
    }

    @Test fun panCullsTiles() {
        // Viewport shows doc x in [2048, 3048).
        val r = TileGrid.visible(ViewTransform(1f, -2048f, 0f), 1000f, 512f, 4096, 4096, TileGrid.TILE, 0f)
        assertEquals(4, r.x0)
        assertEquals(5, r.x1)
        assertEquals(0, r.y0)
        assertEquals(0, r.y1)
    }

    @Test fun lastPartialTileIsIncludedButNotBeyond() {
        val r = TileGrid.visible(ViewTransform(0.1f), 1000f, 1000f, 1100, 1100)
        assertEquals(2, r.x1) // 1100 px -> tiles 0..2
        assertEquals(2, r.y1)
    }

    @Test fun viewOutsideDocumentIsEmpty() {
        val r = TileGrid.visible(ViewTransform(1f, 5000f, 5000f), 800f, 800f, 2000, 2000)
        assertTrue(r.isEmpty)
    }

    @Test fun rotatedViewStillCoversVisibleArea() {
        val v = ViewTransform(1f, 500f, 0f, (Math.PI / 2).toFloat())
        val r = TileGrid.visible(v, 600f, 600f, 4096, 4096)
        assertTrue(!r.isEmpty)
        assertEquals(0, r.x0)
        assertEquals(0, r.y0)
    }

    @Test fun pyramidLevelChoice() {
        assertEquals(0, TilePyramid.levelFor(1.5f, 5))
        assertEquals(0, TilePyramid.levelFor(0.6f, 5))
        assertEquals(1, TilePyramid.levelFor(0.5f, 5))
        assertEquals(1, TilePyramid.levelFor(0.3f, 5))
        assertEquals(2, TilePyramid.levelFor(0.2f, 5))
        assertEquals(3, TilePyramid.levelFor(0.01f, 3)) // clamped to max level
    }
}
