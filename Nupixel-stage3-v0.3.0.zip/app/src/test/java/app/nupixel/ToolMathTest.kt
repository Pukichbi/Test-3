package app.nupixel

import app.nupixel.core.ColorMath
import app.nupixel.core.FloodFill
import app.nupixel.core.StampWalker
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolMathTest {
    private val black = 0xFF000000.toInt()
    private val white = 0xFFFFFFFF.toInt()

    @Test fun stampsAreEvenlySpacedAcrossSegments() {
        val xs = mutableListOf<Float>()
        val w = StampWalker(10f)
        w.begin(0f, 0f) { x, _ -> xs.add(x) }
        w.moveTo(25f, 0f) { x, _ -> xs.add(x) }
        w.moveTo(35f, 0f) { x, _ -> xs.add(x) }
        assertEquals(listOf(0f, 10f, 20f, 30f), xs)
    }

    @Test fun noMovementEmitsNothing() {
        var n = 0
        val w = StampWalker(5f)
        w.begin(3f, 3f) { _, _ -> n++ }
        w.moveTo(3f, 3f) { _, _ -> n++ }
        assertEquals(1, n)
    }

    @Test fun contiguousFillStopsAtDifferentColor() {
        // 4x2: A A B A   (the last A is separated by B)
        val px = intArrayOf(black, black, white, black, black, black, white, black)
        val r = FloodFill.region(px, 4, 2, 0, 0, 0, contiguous = true)
        assertEquals(setOf(0, 1, 4, 5), r.stream().toArray().toSet())
        val all = FloodFill.region(px, 4, 2, 0, 0, 0, contiguous = false)
        assertEquals(6, all.cardinality())
    }

    @Test fun toleranceAcceptsNearbyColors() {
        val near = 0xFF050505.toInt()
        val px = intArrayOf(black, near, white)
        assertEquals(2, FloodFill.region(px, 3, 1, 0, 0, 10, true).cardinality())
        assertEquals(1, FloodFill.region(px, 3, 1, 0, 0, 2, true).cardinality())
    }

    @Test fun maskRestrictsRegion() {
        val px = IntArray(4) { black }
        val mask = byteArrayOf(1, 1, 0, 0)
        val r = FloodFill.region(px, 4, 1, 0, 0, 0, true, mask)
        assertEquals(setOf(0, 1), r.stream().toArray().toSet())
        assertTrue(FloodFill.region(px, 4, 1, 3, 0, 0, true, mask).isEmpty)
    }

    @Test fun seedOutsideImageGivesEmptyRegion() {
        assertTrue(FloodFill.region(IntArray(4), 2, 2, 5, 5, 0, true).isEmpty)
    }

    @Test fun overBlendsStraightAlpha() {
        assertEquals(0xFFFF8080.toInt(), FloodFill.over(white, 0xFFFF0000.toInt(), 0.5f))
        assertEquals(white, FloodFill.over(white, 0xFFFF0000.toInt(), 0f))
        assertEquals(0xFFFF0000.toInt(), FloodFill.over(0, 0xFFFF0000.toInt(), 1f))
    }

    @Test fun hsvRoundTrip() {
        for (c in listOf(0xFF2F7BFF.toInt(), 0xFFFF0000.toInt(), 0xFF00FF80.toInt(), 0xFF808080.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt())) {
            val hsv = ColorMath.argbToHsv(c)
            val back = ColorMath.hsvToArgb(hsv[0], hsv[1], hsv[2])
            for (shift in intArrayOf(16, 8, 0)) {
                assertTrue(Math.abs(((c shr shift) and 0xFF) - ((back shr shift) and 0xFF)) <= 1)
            }
        }
    }

    @Test fun hsvKnownValues() {
        assertEquals(0xFFFF0000.toInt(), ColorMath.hsvToArgb(0f, 1f, 1f))
        assertEquals(0xFF00FF00.toInt(), ColorMath.hsvToArgb(120f, 1f, 1f))
        assertEquals(0xFF0000FF.toInt(), ColorMath.hsvToArgb(240f, 1f, 1f))
        assertFalse(ColorMath.hsvToArgb(0f, 0f, 0.5f) == 0xFF000000.toInt())
    }
}
