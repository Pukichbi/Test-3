package app.nupixel

import app.nupixel.core.Guide
import app.nupixel.data.CURRENT_FORMAT_VERSION
import app.nupixel.data.LayerEntry
import app.nupixel.data.ManifestCodec
import app.nupixel.data.ProjectFormatException
import app.nupixel.data.ProjectManifest
import app.nupixel.data.ProjectTooNewException
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.fail
import org.junit.Test

class ManifestCodecTest {
    private val sample = ProjectManifest(
        appVersion = "0.1.0", name = "Тест / Test", width = 1920, height = 1080,
        createdAt = 1L, modifiedAt = 2L,
        layers = listOf(LayerEntry("layer-1", "Layer 1", "raster", "layers/layer-1.png", visible = false, opacity = 0.5f)),
    )

    @Test fun roundTrip() {
        val back = ManifestCodec.decode(ManifestCodec.encode(sample))
        assertEquals(sample, back)
        assertEquals(CURRENT_FORMAT_VERSION, back.formatVersion)
    }

    @Test fun guidesRoundTripAndAreOptional() {
        val withGuides = sample.copy(guides = listOf(Guide(true, 960), Guide(false, 540)))
        assertEquals(withGuides, ManifestCodec.decode(ManifestCodec.encode(withGuides)))
        val old = JSONObject(ManifestCodec.encode(sample))
        old.remove("guides")
        assertEquals(emptyList<Guide>(), ManifestCodec.decode(old.toString()).guides)
    }

    @Test fun rejectsNewerVersion() {
        val json = JSONObject(ManifestCodec.encode(sample)).put("formatVersion", CURRENT_FORMAT_VERSION + 1).toString()
        try { ManifestCodec.decode(json); fail() } catch (e: ProjectTooNewException) { assertEquals(CURRENT_FORMAT_VERSION + 1, e.version) }
    }

    @Test fun rejectsForeignJson() {
        try { ManifestCodec.decode("{\"hello\":1}"); fail() } catch (e: ProjectFormatException) { assertFalse(e is ProjectTooNewException) }
    }

    @Test fun rejectsGarbage() {
        try { ManifestCodec.decode("not json"); fail() } catch (e: ProjectFormatException) { }
    }

    @Test fun rejectsPathTraversalInLayerFile() {
        val bad = JSONObject(ManifestCodec.encode(sample))
        bad.getJSONArray("layers").getJSONObject(0).put("file", "layers/../../evil.png")
        try { ManifestCodec.decode(bad.toString()); fail() } catch (e: ProjectFormatException) { }
    }

    @Test fun rejectsEmptyLayersAndBadCanvas() {
        val noLayers = JSONObject(ManifestCodec.encode(sample)).put("layers", org.json.JSONArray())
        try { ManifestCodec.decode(noLayers.toString()); fail() } catch (e: ProjectFormatException) { }
        val badCanvas = JSONObject(ManifestCodec.encode(sample))
        badCanvas.getJSONObject("canvas").put("width", 0)
        try { ManifestCodec.decode(badCanvas.toString()); fail() } catch (e: ProjectFormatException) { }
    }
}
