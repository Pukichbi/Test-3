# Project status

**Stage:** 3 — raster tools. Code written, **not built, not run**. Stages 1 and 2 were built via GitHub Actions and accepted by the user.
**Version:** 0.3.0 (versionCode 3)

## Stage 3 done (written, unverified)
- Tools (bottom strip): Pan, Brush, Eraser, Fill, Picker, Remove background, Line, Rectangle, Ellipse, Text, Rect select, Lasso, Move.
- Brush/eraser: size, opacity, hardness; stroke-level opacity; respect the selection.
- Fill and Remove background: tolerance, connected-only option, selection-aware.
- Shapes: outline/filled, line width, opacity, live preview.
- Selection: rectangle and lasso; select all / deselect / clear pixels / fill / crop to selection.
- Move tool: lifts the selected pixels; drag to move, sliders for scale and rotation; Apply / Cancel.
- Text: tap to add, edit in a dialog, drag to move, size/font/bold/italic/colour, Apply to rasterize.
- Colour sheet: HSV sliders, hex, palette; eyedropper.
- One finger drives the tool, two fingers pan/zoom/rotate; a second finger cancels a stroke.
- Undo: one step (also for tool edits). Edits mark the project unsaved; saved/exported through the existing paths.
- Unit tests added for flood fill, blending, HSV, stamp spacing.

## Not done / limits
- Never compiled: expect compile errors on first build.
- No device run: brush feel, tile redraw while painting, gesture switching, text rendering, floating-pixel preview are unverified.
- Only ONE undo step, no redo (stage 5). No layers (stage 4): erasing makes pixels transparent, "background removal" is colour-based and hard-edged.
- Text becomes pixels when applied; editable text objects need layers (stage 4).
- Selections are not saved; no feathering or edge refinement (stage 8). No pressure/stabilizer/texture brushes (stage 7). No on-canvas crop handles.
- Whole-canvas Fill/Remove background run on a copy of the full bitmap (fine up to the size limit, slower on huge canvases).

## Next action
Build, run `testDebugUnitTest`, then check on a device: paint/erase strokes, shapes, selection + move/scale/rotate, fill, remove background, text, undo, save → reopen → export.
